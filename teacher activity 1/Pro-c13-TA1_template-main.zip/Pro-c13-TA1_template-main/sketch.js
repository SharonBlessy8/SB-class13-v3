var input,heading;


function setup() 
{
  createCanvas(400, 400);
  background(178,255,102);
 
}

function draw() {

  
}

